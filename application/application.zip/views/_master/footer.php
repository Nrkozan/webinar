<div class="footer footer-boxed text-muted">
    &copy; 2020 Webinar Kontrol Panel</a>
</div>
<!-- /footer -->

</body>
</html>